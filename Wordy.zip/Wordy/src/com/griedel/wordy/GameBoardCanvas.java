package com.griedel.wordy;

import java.awt.*;
import java.util.Scanner;

public class GameBoardCanvas extends Canvas {
    private final Wordy w;

    public GameBoardCanvas (Wordy w){
        this.w = w;
    }
    public void paint(Graphics g) {

        boolean game = true;
        while(game) {
            String word = Wordy.randomWord();
            word = word.toUpperCase();

            g.setColor(Color.BLACK);
            g.setFont(new Font("TimesRoman", Font.PLAIN, 20));
            g.drawString("Enter a 5-Letter Word",90,20);
            int width = 40;
            int height = 40;
            int b = 50;
            int dif = word.length() - 5;
            int dist = dif * 10;
            int a = 80-dist;
            for(int i = 0; i <= 5; i++)
            {
                for(int k = 0; k < word.length(); k++) {
                    g.drawRect(a, b, width, height);
                    a += 50;
                }
                a = 80-dist;
                b += 50;
            }
            int x = 95;
            int y = 75;


            int count = 0;

            Scanner initial = new Scanner(System.in);
            System.out.println("ENTER YOUR 5-LETTER WORD GUESS:: ");
            String guess = initial.nextLine();
            guess = guess.toUpperCase();




            for (int k = 0; k <= 5; k++) {
                if (count >= 6) {
                    g.setColor(Color.RED);
                    g.drawString("YOU LOSE!!!", 145, 390);
                    System.out.println("YOU LOSE");
                    break;
                }
                System.out.println(word);


                for (int i = 0; i <= 4; i++) {
                    g.setColor(Color.BLACK);
                    if (word.contains(guess.substring(i, i + 1))) {
                        if (word.charAt(i) == guess.charAt(i)) {
                            g.setColor(Color.GREEN);
                            g.drawString(guess.substring(i, i + 1), x, y);
                        } else {
                            g.setColor(Color.ORANGE);
                            g.drawString(guess.substring(i, i + 1), x, y);
                        }
                    } else {
                        g.setColor(Color.BLACK);
                        g.drawString(guess.substring(i, i + 1), x, y);
                    }
                    x += 50;

                }
                y += 50;
                x = 95;
                count += 1;

                if (word.equals(guess)) {
                    g.drawString("YOU WIN!!!", 145, 390);
                    System.out.println("YOU WIN");
                    Scanner type = new Scanner(System.in);
                    System.out.println("Would you like to play again? (yes or no) :: ");
                    String again = type.nextLine();
                    if (again.equals("yes")) {

                        game = true;
                        System.out.println("Hello");
                        guess = "";
                        g.clearRect(0, 0, 400, 500);
                        break;

                    } else {
                        game = false;
                        g.clearRect(0, 0, 400, 500);
                        g.drawString("Thank you for playing", 100, 100);
                        System.out.println("Thank you for playing");
                        break;
                    }


                }

                Scanner enter = new Scanner(System.in);
                System.out.println("ENTER ANOTHER 5-LETTER WORD GUESS:: ");
                guess = enter.nextLine();
                guess = guess.toUpperCase();

            }
        }


    }

}
