package com.griedel.wordy;
import java.util.Random;
import java.awt.*;
import java.awt.Graphics;
import javax.swing.JFrame;
import java.awt.Font;
import java.util.Scanner;
import java.util.*;
import java.util.List;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.awt.EventQueue;

public class Main {







    public static void main(String[] args) {
        Main m = new Main();
        JFrame f=new JFrame();
        Wordy w = new Wordy("junk");
        GameBoardCanvas canvas = new GameBoardCanvas(w);
        String again = "Y";
        f.add(canvas);
        f.setSize(400,500);
        f.setBackground(Color.WHITE);
        //f.setLayout(null);
        f.setVisible(true);


       /* while(again == "Y") {
            f.removeAll();
            f.add(canvas);


        again = "N";

        }*/






    }




}

